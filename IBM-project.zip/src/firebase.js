import { getAuth } from "firebase/auth";
import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCvMDbwVUYi_XsqPskZdOlhrq6BzOvef0s",
  authDomain: "chat-55d06.firebaseapp.com",
  projectId: "chat-55d06",
  storageBucket: "chat-55d06.appspot.com",
  messagingSenderId: "1076356470117",
  appId: "1:1076356470117:web:fc74cb20c76a3eaaf53d8c",
  measurementId: "G-RF6QJRRSVY"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth()
export const storage = getStorage();
export const analytics = getAnalytics(app);
export const db = getFirestore()