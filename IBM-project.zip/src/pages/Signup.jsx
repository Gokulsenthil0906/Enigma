import React, { useState } from 'react'
import add from "../image/addavator.png"
import { createUserWithEmailAndPassword,updateProfile} from "firebase/auth";
import { auth, storage,db} from "../firebase";
import {ref,uploadBytesResumable,getDownloadURL} from "firebase/storage";
import { doc, setDoc } from "firebase/firestore"; 
import { useNavigate } from 'react-router-dom';
const Signup = () => {
  const [err, setErr] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const displayName = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    const file = e.target[3].files[0];

    try {
      // Validate email and password here

      const res = await createUserWithEmailAndPassword(auth, email, password);
      const storageRef = ref(storage, displayName);

      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        (err) => setErr(true),
        async () => {
          getDownloadURL(uploadTask.snapshot.ref).then(async (downloadURL) =>{
          await updateProfile(res.user, {
            displayName,
            photoURL: downloadURL,
          });
          await setDoc(doc(db, "user", res.user.uid), {
            uid: res.user.uid,
            displayName,
            email,
            photoURL: downloadURL,
          });
          await setDoc(doc(db,"userChats",res.user.uid),{

          });

        });
        }
      );
      navigate("/");
    } catch (error) {
      alert(error);
      setErr(true);
    }
  };

  return ( 
    <div className='form-container'>
        <div className='form-wrapper'>
            <spam className="logo">Enigma</spam>
            <h1 className="title">Sign Up</h1>
            <form onSubmit={handleSubmit}>
                <input type="text"  placeholder='User Name'/>
                <input type="email" placeholder='E-mail'/>
                <input type="password" placeholder='Password'/>
                <input style={{display:"none"}} type="file" id="file" placeholder='Add Profile' accept='.jpg,.jpeg,.png'/>
                <label htmlFor="file">
                  <img src={add} alt="" />
                  <span>Add An Avator</span>
                </label>
                <button>Sign up</button>
                {err && <span color='red'>Somethig Went Worng</span>}
            </form>
            <p>Already Have An Accout?<a href="/login">login</a></p>
        </div>
    </div>
  );
};

export default Signup;