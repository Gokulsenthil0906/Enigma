import {useState} from 'react'
import React from 'react'
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';
const Login = () => {
    const navigate = useNavigate();
    const [err, seterr] = useState(false);
   
    const handleSubmit = async (e) => {
      e.preventDefault();
      const email = e.target[0].value;
      const password = e.target[1].value;
  
      try {
        await signInWithEmailAndPassword(auth, email, password);
        navigate("/");
      } catch (err) {
        seterr(true);
        alert("The Given Email-id And Password is Worng");
      }
    };
  return (
    <div className='form-container'>
        <div className='form-wrapper'>
            <span className="logo">Enigma</span>
            <h1 className="title">Login</h1>
            <form onSubmit={handleSubmit}>
                <input type="email" placeholder='E-mail'/>
                <input type="password" placeholder='Password'/>
                <button>Login</button>
                {err && <span>Something Went Worng {err}</span>}
                <p>I Don't Have An Accout?<a href="/signup">Sign Up</a></p>
            </form>
        </div>
    </div>
  )
}

export default Login;